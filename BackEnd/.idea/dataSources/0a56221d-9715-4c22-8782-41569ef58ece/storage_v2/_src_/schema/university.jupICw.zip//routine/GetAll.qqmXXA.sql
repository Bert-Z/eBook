create
  definer = root@localhost function GetAll(id int) returns varchar(20)
BEGIN
	RETURN(select CONCAT('grade: ',grade) from takes where ID=id );
END;

