create
  definer = root@localhost function course_ratio(d_name varchar(255)) returns decimal(10, 2)
begin
	declare res decimal(10,2) default 0;
	declare c_id decimal(10,2);
	declare c_cid decimal(10,2);
	declare c_dname varchar(255);	
	declare done int default false;
	declare cur cursor for 
		select count(distinct ID),count(course_id),dept_name from student natural join takes group by dept_name;
	declare continue HANDLER for not found set done = true;
	
	open cur;
	read_loop:loop
		fetch cur into c_id,c_cid,c_dname;
		if done then
			leave read_loop;
		end if;
		if c_dname = d_name then
			set res = c_cid/c_id;
			leave read_loop;
		end if;
	end loop;
	close cur;
	
	return res;
end;

